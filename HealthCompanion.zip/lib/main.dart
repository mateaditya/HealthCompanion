import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: MedicationScheduleScreen(),
  ));
}

class MedicationScheduleScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Medication Schedule'),
      ),
      body: CalendarWidget(),
    );
  }
}

class CalendarWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            'Medication Schedule',
            style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16.0),
          Text(
              'Calendar-like interface displaying medication scheduling details.'),
          SizedBox(height: 8.0),
          Text('Customization options for reminders.'),
          SizedBox(height: 16.0),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => HealthDashboardScreen()),
              );
            },
            child: Text('Go to Health Dashboard'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => RefillRemindersScreen()),
              );
            },
            child: Text('Go to Refill Reminders'),
          ),
        ],
      ),
    );
  }
}

class HealthDashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Health Dashboard'),
      ),
      body: RealTimeVitalSignsWidget(),
    );
  }
}

class RealTimeVitalSignsWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            'Health Dashboard',
            style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16.0),
          Text(
              'Real-time display of vital signs synced from the wearable device.'),
          SizedBox(height: 8.0),
          Text('Graphical representation of historical health data.'),
        ],
      ),
    );
  }
}

class RefillRemindersScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Refill Reminders'),
      ),
      body: RefillNotificationsWidget(),
    );
  }
}

class RefillNotificationsWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            'Refill Reminders',
            style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 16.0),
          Text('Notifications for upcoming medication refills.'),
          SizedBox(height: 8.0),
          Text('Quick links to local pharmacies for seamless refills.'),
        ],
      ),
    );
  }
}
